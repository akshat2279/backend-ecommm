const config = {
    atlasUrl :process.env.ATLAS,
    local:process.env.DATABASE,
    a:process.env.A
  };
  
  export default config;
  